# -*- coding: utf-8 -*-
import scrapy

# 创建爬虫类 并继承自scrapy.spider
class XicidailiSpider(scrapy.Spider):
    name = 'xicidaili'  # 爬虫名字
    allowed_domains = ['xicidaili.com']  # 允许采集的域名
    start_urls = [f'https://www.xicidaili.com/wt/{page}' for page in range(1,2044)]  # 开始采集的网址
    #　解析响应数据 response就是下载器返回的网页源码
    def parse(self, response):
        
        #　提取数据
        # response.xpath('//tr/td[2]/text()')
        selectors = response.xpath('//tr')
        # 循环遍历tr标签下的td标签
        for selector in selectors:
            ip = selector.xpath('./td[2]/text()').get()  # .在当前节点下继续选择
            port = selector.xpath('./td[3]/text()').get()  #

            # ip = selector.xpath('./td[2]/text()').extract_first()  # .在当前节点下继续选择
            # port = selector.xpath('./td[3]/text()').extract_first() #

            print(ip,port)

        # 翻页操作
        next_page = response.xpath('//a[@class="next_page"]/@href').get()
        if next_page:
            print(next_page)
            next_url = response.urljoin(next_page)
            # 发出请求　　　　callback是回调函数　就是将请求得到的响应交给自己处理
            yield scrapy.response(next_url, callback=self.parse)

# 运行文件：终端找到项目名文件夹进入，输入scrapy crawl xicidaili